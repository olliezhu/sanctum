console.log("Twitter Quiet extension loaded.");
