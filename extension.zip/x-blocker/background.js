console.log("Twitter Feed Blocker extension loaded.");
