# twitter-quiet

Forked from [twitter-x-feed-blocker](https://github.com/akhileshthite/twitter-x-feed-blocker). Install the original extension [here](https://chromewebstore.google.com/detail/twitter-x-feed-blocker/iofjnhbihgjfhdldcnlmjbfmighljfob/).

To run twitter-quiet, download this repository and select it when you `Load unpacked` in [your chromium browser](chrome://extensions/).
